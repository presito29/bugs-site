package com.plannerapp.service.priority;

public interface PriorityService {
    void dbInit();

    boolean isDbInit();
}
